# Google image search example robot using Firefox browser

Executes Google image search and stores the first result image using Firerfox browser and webdriver that are loaded from conda-forge.

Execution is done in fully headless mode so browser will not even be visible and this robot is executable on the Robocorp hosted Cloud Containers as is.
